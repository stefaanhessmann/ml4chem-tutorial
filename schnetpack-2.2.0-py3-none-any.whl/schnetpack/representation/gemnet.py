from typing import Callable, Dict, Union, Optional, List
import torch
from torch import nn
import schnetpack.properties as properties
from schnetpack.nn import Dense, scatter_add
from schnetpack.nn.activations import shifted_softplus

import schnetpack.nn as snn


__all__ = ["GemNet", "GemNetInteraction"]


class GemNetInteraction(nn.Module):
    r"""GemNet interaction block for modeling interactions of atomistic systems.
    
    This implements the directional message passing mechanism from GemNet.
    """

    def __init__(
        self,
        n_atom_basis: int,
        n_rbf: int,
        n_spherical: int,
        n_radial: int,
        n_filters: int,
        activation: Callable = shifted_softplus,
    ):
        """
        Args:
            n_atom_basis: number of features to describe atomic environments
            n_rbf: number of radial basis functions
            n_spherical: number of spherical harmonics
            n_radial: number of radial functions
            n_filters: number of filters used in message passing
            activation: activation function
        """
        super(GemNetInteraction, self).__init__()
        
        # Message passing networks
        self.message_net = nn.Sequential(
            Dense(n_atom_basis, n_filters, activation=activation),
            Dense(n_filters, n_filters, activation=activation),
            Dense(n_filters, n_atom_basis, activation=None)
        )
        
        # Directional message passing
        self.directional_net = nn.Sequential(
            Dense(n_spherical * n_radial, n_filters, activation=activation),
            Dense(n_filters, n_filters, activation=activation),
            Dense(n_filters, n_atom_basis, activation=None)
        )
        
        # Update network
        self.update_net = nn.Sequential(
            Dense(n_atom_basis, n_filters, activation=activation),
            Dense(n_filters, n_atom_basis, activation=None)
        )

    def forward(
        self,
        x: torch.Tensor,
        f_ij: torch.Tensor,
        idx_i: torch.Tensor,
        idx_j: torch.Tensor,
        rcut_ij: torch.Tensor,
        spherical_harmonics: torch.Tensor,
    ):
        """Compute interaction output.

        Args:
            x: input values
            f_ij: radial basis functions
            idx_i: index of center atom i
            idx_j: index of neighbors j
            rcut_ij: cutoff values
            spherical_harmonics: spherical harmonics for directional information

        Returns:
            atom features after interaction
        """
        # Standard message passing
        x_j = x[idx_j]
        Wij = self.message_net(f_ij)
        Wij = Wij * rcut_ij[:, None]
        x_ij = x_j * Wij
        x = scatter_add(x_ij, idx_i, dim_size=x.shape[0])
        
        # Directional message passing
        dir_ij = self.directional_net(spherical_harmonics)
        dir_ij = dir_ij * rcut_ij[:, None]
        dir_ij = x_j * dir_ij
        x = x + scatter_add(dir_ij, idx_i, dim_size=x.shape[0])
        
        # Update
        x = self.update_net(x)
        return x


class GemNet(nn.Module):
    """GemNet architecture for learning representations of atomistic systems.
    
    References:
    .. [#gemnet1] Gasteiger, Becker, Günnemann:
       GemNet: Universal Directional Graph Neural Networks for Molecules.
       NeurIPS 2021.
    """

    def __init__(
        self,
        n_atom_basis: int,
        n_interactions: int,
        radial_basis: nn.Module,
        spherical_basis: nn.Module,
        cutoff_fn: Callable,
        n_filters: int = None,
        n_spherical: int = 7,
        n_radial: int = 6,
        shared_interactions: bool = False,
        activation: Union[Callable, nn.Module] = shifted_softplus,
        nuclear_embedding: Optional[nn.Module] = None,
        electronic_embeddings: Optional[List] = None,
    ):
        """
        Args:
            n_atom_basis: number of features to describe atomic environments
            n_interactions: number of interaction blocks
            radial_basis: layer for expanding interatomic distances in a basis set
            spherical_basis: layer for computing spherical harmonics
            cutoff_fn: cutoff function
            n_filters: number of filters used in message passing
            n_spherical: number of spherical harmonics
            n_radial: number of radial functions
            shared_interactions: if True, share the weights across interaction blocks
            activation: activation function
            nuclear_embedding: custom nuclear embedding
            electronic_embeddings: list of electronic embeddings
        """
        super().__init__()
        self.n_atom_basis = n_atom_basis
        self.n_filters = n_filters or self.n_atom_basis
        self.radial_basis = radial_basis
        self.spherical_basis = spherical_basis
        self.cutoff_fn = cutoff_fn
        self.cutoff = cutoff_fn.cutoff

        # initialize embeddings
        if nuclear_embedding is None:
            nuclear_embedding = nn.Embedding(100, n_atom_basis)
        self.embedding = nuclear_embedding
        if electronic_embeddings is None:
            electronic_embeddings = []
        electronic_embeddings = nn.ModuleList(electronic_embeddings)
        self.electronic_embeddings = electronic_embeddings

        # initialize interaction blocks
        self.interactions = snn.replicate_module(
            lambda: GemNetInteraction(
                n_atom_basis=self.n_atom_basis,
                n_rbf=self.radial_basis.n_rbf,
                n_spherical=n_spherical,
                n_radial=n_radial,
                n_filters=self.n_filters,
                activation=activation,
            ),
            n_interactions,
            shared_interactions,
        )

    def forward(self, inputs: Dict[str, torch.Tensor]):
        # get tensors from input dictionary
        atomic_numbers = inputs[properties.Z]
        r_ij = inputs[properties.Rij]
        idx_i = inputs[properties.idx_i]
        idx_j = inputs[properties.idx_j]

        # compute pair features
        d_ij = torch.norm(r_ij, dim=1)
        f_ij = self.radial_basis(d_ij)
        rcut_ij = self.cutoff_fn(d_ij)
        
        # compute spherical harmonics
        spherical_harmonics = self.spherical_basis(r_ij)

        # compute initial embeddings
        x = self.embedding(atomic_numbers)
        for embedding in self.electronic_embeddings:
            x = x + embedding(x, inputs)

        # compute interaction blocks and update atomic embeddings
        for interaction in self.interactions:
            v = interaction(x, f_ij, idx_i, idx_j, rcut_ij, spherical_harmonics)
            x = x + v

        # collect results
        inputs["scalar_representation"] = x

        return inputs 