import torch
from torch import nn
import math
from typing import Optional, Tuple

__all__ = ["SphericalBasis"]


class SphericalBasis(nn.Module):
    """Spherical harmonics basis for directional information.
    
    This module computes spherical harmonics up to a given order for
    directional message passing in GemNet.
    """

    def __init__(
        self,
        max_l: int = 2,
        cutoff: float = 5.0,
        use_phi: bool = True,
    ):
        """
        Args:
            max_l: maximum angular momentum (l)
            cutoff: cutoff radius
            use_phi: whether to use azimuthal angle (phi)
        """
        super().__init__()
        self.max_l = max_l
        self.cutoff = cutoff
        self.use_phi = use_phi
        
        # Number of spherical harmonics
        self.n_spherical = (max_l + 1) ** 2
        
        # Precompute factorial values
        self.factorial = torch.tensor([math.factorial(i) for i in range(2 * max_l + 1)])
        
        # Precompute associated Legendre polynomial coefficients
        self.legendre_coeffs = self._compute_legendre_coeffs()

    def _compute_legendre_coeffs(self) -> torch.Tensor:
        """Compute coefficients for associated Legendre polynomials."""
        coeffs = []
        for l in range(self.max_l + 1):
            for m in range(-l, l + 1):
                coeff = torch.zeros(2 * l + 1)
                for k in range(l + 1):
                    if k >= abs(m):
                        coeff[k] = (-1) ** k * math.comb(l, k) * math.comb(l + k, k)
                coeffs.append(coeff)
        return coeffs  # Return as list, not stacked tensor

    def _compute_legendre(self, x: torch.Tensor, l: int, m: int) -> torch.Tensor:
        """Compute associated Legendre polynomial P_l^m(x)."""
        idx = l * (l + 1) + m
        coeff = self.legendre_coeffs[idx]  # coeff is 1D tensor of length (2*l+1)
        result = torch.zeros_like(x)
        for i, c in enumerate(coeff):
            if c != 0:
                result = result + c * (x ** i)
        if m != 0:
            result = result * (1 - x ** 2).pow(abs(m) / 2)
        return result  # Always (N_pairs,)

    def _compute_spherical_harmonics(
        self, r_ij: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute spherical harmonics for given positions.
        
        Args:
            r_ij: relative positions between atoms (N_pairs, 3)
            
        Returns:
            Tuple of (theta, phi) angles
        """
        r = torch.norm(r_ij, dim=1)  # (N_pairs,)
        theta = torch.acos(r_ij[:, 2] / r)  # (N_pairs,)
        phi = torch.atan2(r_ij[:, 1], r_ij[:, 0])  # (N_pairs,)
        return theta, phi

    def forward(self, r_ij: torch.Tensor) -> torch.Tensor:
        """Compute spherical harmonics basis.
        
        Args:
            r_ij: relative positions between atoms (N_pairs, 3)
            
        Returns:
            Spherical harmonics basis (N_pairs, n_spherical)
        """
        theta, phi = self._compute_spherical_harmonics(r_ij)  # both (N_pairs,)
        cos_theta = torch.cos(theta)  # (N_pairs,)
        y_lm = []
        for l in range(self.max_l + 1):
            for m in range(-l, l + 1):
                p_lm = self._compute_legendre(cos_theta, l, abs(m))  # (N_pairs,)
                if m == 0:
                    y = p_lm
                else:
                    if self.use_phi:
                        if m > 0:
                            y = p_lm * torch.cos(m * phi)
                        else:
                            y = p_lm * torch.sin(abs(m) * phi)
                    else:
                        y = p_lm
                y_lm.append(y)  # y is always (N_pairs,)
        return torch.stack(y_lm, dim=1)  # (N_pairs, n_spherical) 